/*
 * rlm_cas.c
 *
 * Version: $Id:$
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Copyright 2001  The FreeRADIUS server project
 * Copyright 2006-2009  Christophe BORELLY <cb@iutbeziers.fr>
 */

#include <freeradius-devel/ident.h>
RCSID("$Id$")

#include <freeradius-devel/radiusd.h>
#include <freeradius-devel/modules.h>

#include <ctype.h>  // isspace
#include <regex.h>  // regcomp,regexec,regfree,regerror
#include <curl/curl.h>
#include <libxml/xmlreader.h>

/*
 *      Define a structure for our module configuration.
 *
 *      These variables do not need to be in a structure, but it's
 *      a lot cleaner to do so, and a pointer to the structure can
 *      be used as the instance handle.
 */
typedef struct rlm_cas_t {
	int debug;           // no
	char *host;          // cas.pepperspot.info
	int port;            // 8443
	char *url;           // Empty for /
	char *applet;        // CAS v2 : serviceValidate, proxyValidate
	char *service;       // cas://PepperSpot
	char *ticketPattern; // ^ST-[[:digit:]]+-[[:alnum:]]+-cas$ ou bien ^ST-[0-9]+-[a-zA-Z0-9]+-cas$
	int verify_peer;     // yes (cf. verify_host)
	int verify_host;     // 0 None, 1 Existance of CN, 2 CN=Hostname (default)
	char *cainfo;        // /usr/local/apache2/conf/ca.crt
	char *capath;        // NULL
} rlm_cas_t;

/*
 *      A mapping of configuration file names to internal variables.
 *
 *      Note that the string is dynamically allocated, so it MUST
 *      be freed.  When the configuration file parse re-reads the string,
 *      it free's the old one, and strdup's the new one, placing the pointer
 *      to the strdup'd string into 'config.string'.  This gets around
 *      buffer over-flows.
 */
static CONF_PARSER module_config[] = {
  { "debug", PW_TYPE_BOOLEAN, offsetof(rlm_cas_t,debug), NULL, "no" },
  { "host", PW_TYPE_STRING_PTR, offsetof(rlm_cas_t,host), NULL, "cas.pepperspot.info" },
  { "port", PW_TYPE_INTEGER, offsetof(rlm_cas_t,port), NULL, "8443" },
  { "url", PW_TYPE_STRING_PTR, offsetof(rlm_cas_t,url), NULL, "" },
  { "applet", PW_TYPE_STRING_PTR, offsetof(rlm_cas_t,applet), NULL, "proxyValidate" },
  { "service", PW_TYPE_STRING_PTR, offsetof(rlm_cas_t,service), NULL, "cas://PepperSpot" },
  { "ticketPattern", PW_TYPE_STRING_PTR, offsetof(rlm_cas_t,ticketPattern), NULL, "^ST-[[:digit:]]+-[[:alnum:]]+-cas$" },
  { "verify_peer", PW_TYPE_BOOLEAN, offsetof(rlm_cas_t,verify_peer), NULL, "yes" },
  { "verify_host", PW_TYPE_INTEGER, offsetof(rlm_cas_t,verify_host), NULL, "2" },
  { "cainfo", PW_TYPE_STRING_PTR, offsetof(rlm_cas_t,cainfo), NULL, "/usr/local/apache2/conf/ca.crt" },
  { "capath", PW_TYPE_STRING_PTR, offsetof(rlm_cas_t,capath), NULL, NULL },
  { NULL, -1, 0, NULL, NULL }
};

/* (Re-)read configuration */
static int cas_instantiate(CONF_SECTION *conf,void **instance)
{
	rlm_cas_t *inst;
	DEBUG("rlm_cas: cas_instantiate()...");
	inst=rad_malloc(sizeof(*inst));
	if (!inst) {
		return -1;
	}
	memset(inst,0,sizeof(*inst));
	if (cf_section_parse(conf,inst,module_config)<0) {
		free(inst);
		return -1;
	}
	*instance=inst;
	return 0;
}
/* Only free memory we allocated. The strings allocated via
 * cf_section_parse() do not need to be freed. */
static int cas_detach(void *instance)
{
	DEBUG("rlm_cas: cas_detach()...");
	free(instance);
	return 0;
}

// Structure used in cas_authenticate()
typedef struct CASinfos {
	xmlChar *user;
	xmlChar *errCode;
	xmlChar *errText;
} CASinfos;

// Initialisation of the structure
void initCASinfos(CASinfos *cas)
{
	cas->user=NULL;
	cas->errCode=NULL;
	cas->errText=NULL;
}
void freeCASinfos(CASinfos *cas)
{
	if (cas->user!=NULL) xmlFree(cas->user);
	if (cas->errCode!=NULL) xmlFree(cas->errCode);
	if (cas->errText!=NULL) xmlFree(cas->errText);
}
/**
 * strstrip - Removes leading and trailing whitespace from @s.
 * @s: The string to be stripped.
 *
 * From kernel patch 2006-04
 *
 * Note that the first trailing whitespace is replaced with a %NUL-terminator
 * in the given string @s. Returns a pointer to the first non-whitespace
 * character in @s.
 */
char *strstrip(char *s)
{
	size_t size;
	char *end;
	size=strlen(s);
	if (!size) return s;
	end=s+size-1;
	while (end!=s&&isspace(*end)) end--;
	*(end+1)='\0';
	while (*s&&isspace(*s)) s++;
	return s;
}
/**
CAS XML response examples :
<cas:serviceResponse xmlns:cas='http://www.yale.edu/tp/cas'>
  <cas:authenticationSuccess>
    <cas:user>cb</cas:user>
    <cas:proxies>
      <cas:proxy>https://chilli.IUTBeziers.Fr/hotspotlogin.php</cas:proxy>
    </cas:proxies>
  </cas:authenticationSuccess>
</cas:serviceResponse>

<cas:serviceResponse xmlns:cas='http://www.yale.edu/tp/cas'>
  <cas:authenticationFailure code='INVALID_TICKET'>
    ticket 'ST-3-byCd9tJdIgcBLrFKiIAE-cas' not recognized
  </cas:authenticationFailure>
</cas:serviceResponse>
*/
// Parse XML response from CAS server (used in cas_authenticate())
void parseCASXML(xmlNodePtr cur,rlm_cas_t *inst,CASinfos *cas)
{
	xmlChar *msg;
	while (cur!=NULL)
	{
		if (inst->debug) radlog(L_DBG,"rlm_cas: NAME [%s] TYPE [%d]",cur->name,cur->type);
		if ((xmlStrcmp(cur->name,(xmlChar *)"user")==0))
		{
			cas->user=xmlNodeGetContent(cur);
			if (inst->debug) radlog(L_DBG,"rlm_cas: USER [%s]",cas->user);
		}
		if ((xmlStrcmp(cur->name,(xmlChar *)"authenticationFailure")==0))
		{
				cas->errCode=xmlGetProp(cur,(xmlChar *)"code");
				if (inst->debug) radlog(L_DBG,"rlm_cas: CODE [%s]",cas->errCode);
				msg=xmlNodeGetContent(cur);
				if (msg)
				{
					cas->errText=xmlCharStrdup(strstrip((char*)msg));
					if (inst->debug) radlog(L_DBG,"rlm_cas: TEXT [%s]",cas->errText);
					xmlFree(msg);
				}
		}
		parseCASXML(cur->children,inst,cas);
		cur=cur->next;
	}
}
/*
Possible return codes and their meaning :
RLM_MODULE_REJECT    This request is not permitted under local policy. FreeRADIUS responds immediately with a reject response.
RLM_MODULE_FAIL      Processing of this request could not be completed. Something is not working properly.
                     FreeRADIUS responds with a reject response.
RLM_MODULE_OK        This request is permitted or this module has processed the request successfully.
                     The FreeRADIUS response will be determined by processing of later modules.
                     If this is the last module then the response will be an OK
RLM_MODULE_HANDLED   The module handled the request, so stop
RLM_MODULE_INVALID   The module considers the request invalid
RLM_MODULE_USERLOCK  Reject the request (user is locked out)
RLM_MODULE_NOTFOUND  User not found (Probably shouldn�t be used in a RLM)
RLM_MODULE_NOOP      Module succeeded without doing anything
RLM_MODULE_UPDATED   OK (pairs modified)
RLM_MODULE_NUMCODES  How many return codes there are
 *
 * 1-Generate CAS validation URL :
 * Something like : https://cas.iutbeziers.fr:8443/proxyValidate?service=cas%3A%2F%2FChilliSpot&ticket=ST%2D3%2DbyCd9tJdIgcBLrFKiIAE%2Dcas
 * 2-Read CAS server response
 * 3-Parse XML to find user and compare with RADIUS UserName
 * 4-Return RADIUS code
 */
static int cas_authenticate(void *instance,REQUEST *request)
{
	FILE *out;
	CURL *curl;
	CURLcode curlCode;
	xmlDocPtr doc=NULL;
	CASinfos cas;
	char *outFileName;
	char *serviceEncoded;
	char *ticketEncoded;
	char curlErrBuffer[CURL_ERROR_SIZE];
	char validateURL[MAX_STRING_LEN];
	rlm_cas_t *inst=(rlm_cas_t *)instance;
	int result=RLM_MODULE_FAIL;

	RDEBUG("cas_authenticate()...");
	outFileName=tmpnam(NULL);
	//RDEBUG2("Temporary file [%s]...",outFileName);
	if (!(out=fopen(outFileName,"w")))
	{
		// L_DBG, L_AUTH, L_INFO, L_ERR, L_PROXY, L_ACCT, L_CONS
		radlog(L_AUTH,"rlm_cas: Unable to open [%s] !!!",outFileName);
		return RLM_MODULE_INVALID;
	}
	if (!request->username)
	{
		radlog(L_AUTH,"rlm_cas: \"User-Name\" is required !!!");
		return RLM_MODULE_INVALID;
	}
	// Also verified in cas_authorize()
	if (!request->password)
	{
		RDEBUG("A \"password\" field is required !!!");
		return RLM_MODULE_INVALID;
	}
	if (request->password->attribute!=PW_PASSWORD)
	{
		RDEBUG("\"%s\" is not supported !!!",request->password->name);
		return RLM_MODULE_INVALID;
	}
	if (request->password->length==0)
	{
		VALUE_PAIR *reply_item;
		char msg[MAX_STRING_LEN];
		radlog(L_AUTH,"rlm_cas: Empty password !!!");
		snprintf(msg,sizeof(msg),"rlm_cas: Empty password !!!");
		reply_item=pairmake("Reply-Message",msg,T_OP_EQ);
		pairadd(&request->reply->vps,reply_item);
		return RLM_MODULE_INVALID;
	}
	RDEBUG2("RADIUS USER [%s]",request->username->vp_strvalue);
	RDEBUG2("RADIUS PASS [%s]",request->password->vp_strvalue);
	curl=curl_easy_init();
	if (curl)
	{
		// Since cURL 7.15.4 use curl_easy_escape() instead of curl_escape()
		serviceEncoded=curl_easy_escape(curl,inst->service,0);
		ticketEncoded=curl_easy_escape(curl,request->password->vp_strvalue,0);
		snprintf(validateURL,sizeof(validateURL),"https://%s:%d%s/%s?service=%s&ticket=%s"
			,inst->host,inst->port,inst->url,inst->applet,serviceEncoded,ticketEncoded);
		curl_free(serviceEncoded);
		curl_free(ticketEncoded);
		RDEBUG("ValidateURL [%s]",validateURL);
		curl_easy_setopt(curl,CURLOPT_URL,validateURL);
		curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,NULL);
		curl_easy_setopt(curl,CURLOPT_WRITEDATA,out);
		curl_easy_setopt(curl,CURLOPT_ERRORBUFFER,curlErrBuffer);
		curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,inst->verify_peer);
		curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,inst->verify_host);
		if (inst->cainfo) curl_easy_setopt(curl,CURLOPT_CAINFO,inst->cainfo);
		if (inst->capath) curl_easy_setopt(curl,CURLOPT_CAPATH,inst->capath);
		curlCode=curl_easy_perform(curl);
		curl_easy_cleanup(curl);
		fclose(out);
		if (curlCode)
		{
 			radlog(L_ERR,"rlm_cas: cURL failed for [%s]",validateURL);
			RDEBUG("cURL : %s",curl_easy_strerror(curlCode));
			RDEBUG("cURL : %s",curlErrBuffer);
			result=RLM_MODULE_FAIL;
		}
		else
		{
			if (inst->debug)
			{
				RDEBUG("CAS server response...");
				if ((out=fopen(outFileName,"r")))
				{
					while(!feof(out))
					{
						char ligne[MAX_STRING_LEN];
						RDEBUG("%s",fgets(ligne,MAX_STRING_LEN,out));
					}
					fclose(out);
				}
				else
				{
					RDEBUG("Unable to read [%s] !!!",outFileName);
				}
			}
			xmlInitParser();
			doc=xmlParseFile(outFileName);
			if (doc==NULL)
			{
				RDEBUG("Unable to parse XML response !!!");
				xmlErrorPtr err=xmlGetLastError();
				if (err!=NULL) RDEBUG("XML : %s",err->message);
				result=RLM_MODULE_FAIL;
			}
			else
			{
				initCASinfos(&cas);
				RDEBUG("Parsing XML response...");
				parseCASXML(xmlDocGetRootElement(doc),inst,&cas);
				if (cas.user!=NULL)
				{
					RDEBUG("CAS USER [%s]",cas.user);
					if (strcmp((char*)cas.user,request->username->vp_strvalue)==0) // Same user !!!
					{
						RDEBUG("User authenticated succesfully");

						/*VALUE_PAIR *reply_item;
						char msg[MAX_STRING_LEN];
						snprintf(msg,sizeof(msg),"Bienvenue %s !",request->username->vp_strvalue);
						reply_item=pairmake("Reply-Message",msg,T_OP_EQ);
						pairadd(&request->reply->vps,reply_item);*/

						/*reply_item=radius_paircreate(request,&request->reply->vps,PW_SESSION_TIMEOUT,PW_TYPE_INTEGER);
						reply_item->vp_integer=120;*/

						/*reply_item=radius_paircreate(request,&request->reply->vps,PW_IDLE_TIMEOUT,PW_TYPE_INTEGER);
						reply_item->vp_integer=300;*/

						/*char msg[MAX_STRING_LEN];
						snprintf(msg,sizeof(msg),"%d",600);
						reply_item=pairmake("Acct-Interim-Interval",msg,T_OP_EQ);
						pairadd(&request->reply->vps,reply_item);*/

						result=RLM_MODULE_OK;
					}
					else
					{
						RDEBUG("Wrong CAS user [%s][%s]",cas.user,request->username->vp_strvalue);
						result=RLM_MODULE_REJECT;
					}
				}
				if (cas.errCode!=NULL)
				{
					RDEBUG("CODE [%s]",cas.errCode);
					if (cas.errText!=NULL)
					{
						RDEBUG("TEXT [%s]",cas.errText);
					}
					result=RLM_MODULE_REJECT;
				}
				freeCASinfos(&cas);
				xmlFreeDoc(doc);
				xmlCleanupParser();
			}
		}
	}
	else
	{
		RDEBUG("cURL initialisation failed !!!");
	}
	//RDEBUG2("Unlink [%s]...",outFileName);
	unlink(outFileName);
	return result;
}
/* Check if user is authorized for remote access
 * Setting Auth-type attribute for automatic call to cas_authenticate()
 *
 * Autorizes all passwords that match ticket pattern (see cas.conf)
 */
static int cas_authorize(void *instance,REQUEST *request)
{
	rlm_cas_t *inst=(rlm_cas_t *)instance;

	RDEBUG("cas_authorize()...");
	if (pairfind(request->config_items,PW_AUTHTYPE)!=NULL)
	{
		RDEBUG("\"%s\" already exists [%s] !!!"
				,request->config_items->name
				,request->config_items->vp_strvalue);
		return RLM_MODULE_NOOP;
	}
	if (!request->password)
	{
		RDEBUG("A \"password\" field is required !!!");
		return RLM_MODULE_NOOP;
	}
	if (request->password->attribute!=PW_PASSWORD)
	{
		RDEBUG("\"%s\" is not supported !!!"
				,request->password->name);
		return RLM_MODULE_NOOP;
	}
	// Ticket pattern verification (e.g. ST-3-byCd9tJdIgcBLrFKiIAE-cas)
	regex_t expr;
	RDEBUG("PATTERN [%s]...",inst->ticketPattern);
	RDEBUG("PASSWORD [%s]...",request->password->vp_strvalue);
	int rc=regcomp(&expr,inst->ticketPattern,REG_NOSUB|REG_EXTENDED); // Compilation
	if (rc==0)
	{
		int match=regexec(&expr,request->password->vp_strvalue,0,NULL,0); // Search
		regfree(&expr); // Freeing memory
		if (match==0) // Ok
		{
			RDEBUG("Setting Auth-Type...");
			pairadd(&request->config_items,pairmake("Auth-Type","CAS",T_OP_EQ));
			return RLM_MODULE_UPDATED;
		}
		else if (match==REG_NOMATCH) // No results
		{
			//RDEBUG("regexec() : no match...");
		}
		else // Search error
		{
			RDEBUG("regexec() : %d",match);
			size_t size=regerror(match,&expr,NULL,0);
			char *text=malloc(sizeof(char)*size);
			if (text)
			{
				regerror(match,&expr,text,size);
				radlog(L_ERR,"rlm_cas: regexec() failed !!!");
				radlog(L_ERR,"rlm_cas: %s",text);
				free(text);
			}
		}
	}
	else // Compilation error
	{
		RDEBUG("regcomp() : %d",rc);
		size_t size=regerror(rc,&expr,NULL,0);
		char *text=malloc(sizeof(char)*size);
		if (text)
		{
			regerror(rc,&expr,text,size);
			radlog(L_ERR,"rlm_cas: regcomp() failed !!!");
			radlog(L_ERR,"rlm_cas: %s",text);
			free(text);
		}
	}
	return RLM_MODULE_NOOP;
}
static int cas_preaccounting(void *instance,REQUEST *request)
{
	RDEBUG("cas_preaccounting()...");
	return RLM_MODULE_OK;
}
static int cas_accounting(void *instance,REQUEST *request)
{
	RDEBUG("cas_accounting()...");
	return RLM_MODULE_OK;
}
static int cas_checksimul(void *instance,REQUEST *request)
{
	RDEBUG("cas_checksimul()...");
	return RLM_MODULE_OK;
}
static int cas_preproxy(void *instance,REQUEST *request)
{
	RDEBUG("cas_preproxy()...");
	return RLM_MODULE_OK;
}
static int cas_postproxy(void *instance,REQUEST *request)
{
	RDEBUG("cas_postproxy()...");
	return RLM_MODULE_OK;
}
static int cas_postauth(void *instance,REQUEST *request)
{
	RDEBUG("cas_postauth()...");
	return RLM_MODULE_OK;
}

/*
 *      The module name should be the only globally exported symbol.
 *      That is, everything else should be 'static'.
 *
 *      If the module needs to temporarily modify it's instantiation
 *      data, the type should be changed to RLM_TYPE_THREAD_UNSAFE.
 *      The server will then take care of ensuring that the module
 *      is single-threaded.
 */
module_t rlm_cas = {
	RLM_MODULE_INIT,
	"CAS",
	RLM_TYPE_THREAD_SAFE,   // type
	cas_instantiate,        // instantiation
	cas_detach,             // detach
	{
		cas_authenticate,   // authentication
		cas_authorize,      // authorization
		cas_preaccounting,  // preaccounting
		cas_accounting,     // accounting
		cas_checksimul,     // checksimul
		cas_preproxy,       // pre-proxy
		cas_postproxy,      // post-proxy
		cas_postauth        // post-auth
	},
};
