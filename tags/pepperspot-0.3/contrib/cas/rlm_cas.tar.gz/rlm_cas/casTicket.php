<?php
define('LF',"\n");
define('CAS_LIB_DIR','CAS-1.0.1');
define('CAS_SERVER','cas.pepperspot.info');
define('CAS_PORT',8443);
define('CAS_URL','');
define('CAS_SERVICE','cas://PepperSpot');
//define('CAS_CACERT','/usr/local/apache2/conf/ca.crt');
# CAS_PGT_STORAGE must be set on Windows Systems
define('CAS_PGT_STORAGE','C:/Tmp');

require_once(CAS_LIB_DIR.'/CAS.php');
// phpCAS logs in /tmp/phpCAS.log 
//phpCAS::setDebug();
phpCAS::proxy(CAS_VERSION_2_0,CAS_SERVER,CAS_PORT,CAS_URL);
if (defined('CAS_CACERT')) phpCAS::setCasServerCACert(CAS_CACERT);
else phpCAS::setNoCasServerValidation();
if (isset($_SERVER['WINDIR'])) phpCAS::setPGTStorageFile('',CAS_PGT_STORAGE);
if (isset($_REQUEST['logout']))
{
  //phpCAS::logout();
  phpCAS::logoutWithUrl('http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);
  //phpCAS::logoutWithRedirectService('http://'.$_SERVER['HTTP_HOST']);
}
phpCAS::forceAuthentication();

// Get ticket
$pt=phpCAS::retrievePT(CAS_SERVICE,$err_code,$output);
echo '<p>USER   : '.phpCAS::getUser().'</p>'.LF;
echo '<p>TICKET : '.$pt.'</p>'.LF;
echo '<a href="'.$_SERVER['PHP_SELF'].'">NEW TICKET</a><br/>'.LF;
echo '<a href="'.$_SERVER['PHP_SELF'].'?logout">Deconnection</a>'.LF;
?>
